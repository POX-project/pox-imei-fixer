#!/system/bin/sh
# ========================================================
#  POX KERNEL MODEM & IMEI RESTORATION RUNTIME HOOK
#  Redmi Note 8 Pro (begonia) - MT6785 / Helio G90T
# ========================================================

MODDIR="${0%/*}"
MODDIRV="$MODDIR/vendor/lib/modules"
LOGFILE="/data/local/tmp/pox_imei_patcher.log"

log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') [*] $*" >> "$LOGFILE" 2>/dev/null || echo "[*] $*"
}

log "========================================================"
log " POX KERNEL MODEM PATCHER BOOT SERVICE"
log "========================================================"

insmod="$MODDIR/bin/insmod2"
chmod +x "$insmod" 2>/dev/null || true

# Restore SELinux contexts to prevent permission denials in Enforcing mode
chcon -R u:object_r:vendor_file:s0 "$MODDIR/vendor" 2>/dev/null || true
chcon -R u:object_r:system_file:s0 "$MODDIR/bin" 2>/dev/null || true
chcon u:object_r:system_file:s0 "$MODDIR/system.prop" 2>/dev/null || true

# Enforce MediaTek VoLTE / IMS & Telephony runtime properties
if [ -x "$MODDIR/bin/resetprop" ]; then
  log "[*] Enforcing MediaTek VoLTE & Telephony runtime properties..."
  "$MODDIR/bin/resetprop" -n persist.vendor.radio.volte_state 1 2>/dev/null || true
  "$MODDIR/bin/resetprop" -n persist.vendor.volte_support 1 2>/dev/null || true
  "$MODDIR/bin/resetprop" -n persist.vendor.vilte_support 1 2>/dev/null || true
  "$MODDIR/bin/resetprop" -n persist.vendor.vowifi_support 1 2>/dev/null || true
  "$MODDIR/bin/resetprop" -n persist.vendor.viwifi_support 1 2>/dev/null || true
  "$MODDIR/bin/resetprop" -n persist.dbg.volte_avail_ovr 1 2>/dev/null || true
  "$MODDIR/bin/resetprop" -n persist.dbg.vt_avail_ovr 1 2>/dev/null || true
  "$MODDIR/bin/resetprop" -n persist.dbg.wfc_avail_ovr 1 2>/dev/null || true
  "$MODDIR/bin/resetprop" -n persist.vendor.mtk.volte.enable 1 2>/dev/null || true
  "$MODDIR/bin/resetprop" -n persist.vendor.radio.imsStkSupport 1 2>/dev/null || true
  "$MODDIR/bin/resetprop" -n persist.vendor.radio.mtk_dsbp_support 2 2>/dev/null || true
  "$MODDIR/bin/resetprop" -n persist.vendor.radio.smart.data.switch 1 2>/dev/null || true
  "$MODDIR/bin/resetprop" -n persist.radio.multisim.config dsds 2>/dev/null || true

  # Check active SIM slots and route primary 4G/VoLTE capability
  SIM1="$(getprop gsm.sim.state 2>/dev/null | cut -d',' -f1)"
  SIM2="$(getprop gsm.sim.state 2>/dev/null | cut -d',' -f2)"
  if [ "$SIM1" = "ABSENT" ] && [ "$SIM2" = "LOADED" ]; then
    log "[*] SIM detected in Slot 2 only; routing primary capability to Slot 2..."
    "$MODDIR/bin/resetprop" -n persist.vendor.radio.c_capability_slot 2 2>/dev/null || true
    "$MODDIR/bin/resetprop" -n persist.vendor.radio.simswitch 2 2>/dev/null || true
    "$MODDIR/bin/resetprop" -n persist.vendor.radio.prefer_data_slot 2 2>/dev/null || true
  fi
fi

KVER="$(uname -r)"
log "Running Kernel: $KVER"

# 1. Match native module for exact kernel release
module="$MODDIRV/md_patcher-${KVER}.ko"

# 2. Fallback to generic or prebuilt modules
if [ ! -f "$module" ]; then
  log "No direct match for md_patcher-${KVER}.ko; checking fallback modules..."
  if [ -f "$MODDIRV/md_patcher.ko" ]; then
    module="$MODDIRV/md_patcher.ko"
  else
    for cand in "$MODDIRV"/md_patcher-*.ko; do
      if [ -f "$cand" ]; then
        module="$cand"
        break
      fi
    done
  fi
fi

if [ -n "$module" ] && [ -f "$module" ]; then
  log "Target Module: $(basename "$module")"
  
  # Attempt insmod (Pox Kernel supports native and force-load via insmod2 -f)
  if "$insmod" "$module" >> "$LOGFILE" 2>&1; then
    log "[+] SUCCESS: Modem RSA patcher loaded natively into kernel!"
  elif "$insmod" -f "$module" >> "$LOGFILE" 2>&1; then
    log "[+] SUCCESS: Modem RSA patcher force-loaded into kernel!"
  elif insmod "$module" >> "$LOGFILE" 2>&1; then
    log "[+] SUCCESS: Modem RSA patcher loaded via fallback insmod!"
  else
    # Note: md_patcher returns -25 (ENOTTY) by design after patching memory, which insmod treats as non-zero.
    # Check dmesg to confirm memory was patched.
    if dmesg 2>/dev/null | grep -q "md_patcher: modulus after"; then
      log "[+] SUCCESS: Modem RSA modulus successfully patched in memory (confirmed via dmesg)!"
    else
      log "[!] Notice: Module loader returned status code, verifying modem status."
    fi
  fi
else
  log "[-] No suitable md_patcher.ko found, applying P0 hwlevel fallback..."
  chmod +x "$MODDIR/bin/resetprop" 2>/dev/null || true
  "$MODDIR/bin/resetprop" ro.boot.hwlevel P0 2>/dev/null || true
fi

log "Pox Modem Patcher execution finished."
