#!/system/bin/sh
# ========================================================
#  POX KERNEL MODEM & IMEI RESTORATION SUITE
#  Universal In-OS Installer Hook (FolkPatch / APatch / KSU / Magisk)
# ========================================================

ui_print " "
ui_print " ========================================================"
ui_print "       POX KERNEL MODEM & IMEI RESTORATION SUITE         "
ui_print " ========================================================"
ui_print "   Device      : Redmi Note 8 Pro (begonia)              "
ui_print "   Author      : TXO R & Antigravity (Pox Project)       "
ui_print "   Engine      : Universal NVRAM/NVDATA + Pox md_patcher "
ui_print "   Target      : FolkPatch / APatch / KernelSU / Magisk  "
ui_print " ========================================================"
ui_print " "

find_partition_block() {
  local name="$1"
  for path in \
    "/dev/block/by-name/$name" \
    "/dev/block/platform/bootdevice/by-name/$name" \
    "/dev/block/bootdevice/by-name/$name" \
    "/dev/block/platform/*/*/by-name/$name"; do
    if [ -b "$path" ]; then
      echo "$path"
      return 0
    fi
  done
  return 1
}

# ---------------------------------------------------------
# STAGE 1: Environment Verification
# ---------------------------------------------------------
ui_print " [*] [1/5] Verifying environment & root manager..."
if [ -n "$APATCH" ] || [ -n "$APATCH_VER" ]; then
  ui_print "     - Root Engine : FolkPatch / APatch (active)"
elif [ -n "$KSU" ] || [ -n "$KSU_VER" ]; then
  ui_print "     - Root Engine : KernelSU (active)"
elif [ -n "$MAGISK_VER" ]; then
  ui_print "     - Root Engine : Magisk $MAGISK_VER (active)"
else
  ui_print "     - Root Engine : Universal Android Root"
fi
ui_print "     - Kernel Ver  : $(uname -r)"

# ---------------------------------------------------------
# STAGE 2: Automated Full Modem Partition Backup
# ---------------------------------------------------------
ui_print " "
ui_print " [*] [2/5] Creating automated full modem partition backup..."
TIMESTAMP="$(date +%Y%m%d_%H%M%S 2>/dev/null || echo "timestamp")"
BACKUP_DIR=""
for cand in "/sdcard/Pox_Backups/Modem_${TIMESTAMP}" \
            "/data/media/0/Pox_Backups/Modem_${TIMESTAMP}" \
            "/tmp/Pox_Backups/Modem_${TIMESTAMP}"; do
  mkdir -p "$cand" 2>/dev/null || continue
  if [ -d "$cand" ]; then
    BACKUP_DIR="$cand"
    break
  fi
done

if [ -n "$BACKUP_DIR" ]; then
  ui_print "     - Backup Destination: $BACKUP_DIR"
  MODEM_PARTS="nvram nvdata nvcfg protect1 protect2 protect_f protect_s proinfo md1img"
  BACKUP_COUNT=0
  for part in $MODEM_PARTS; do
    BLK=$(find_partition_block "$part")
    if [ -n "$BLK" ] && [ -b "$BLK" ]; then
      OUT_FILE="$BACKUP_DIR/${part}.img"
      dd if="$BLK" of="$OUT_FILE" bs=1048576 2>/dev/null || cat "$BLK" > "$OUT_FILE" 2>/dev/null || true
      if [ -f "$OUT_FILE" ] && [ -s "$OUT_FILE" ]; then
        SZ=$(stat -c %s "$OUT_FILE" 2>/dev/null || wc -c < "$OUT_FILE" 2>/dev/null || echo "0")
        SZ_MB=$(( SZ / 1048576 ))
        ui_print "     [+] Backed up $part (${SZ_MB}MB) -> ${part}.img"
        sha256sum "$OUT_FILE" >> "$BACKUP_DIR/checksums.sha256" 2>/dev/null || md5sum "$OUT_FILE" >> "$BACKUP_DIR/checksums.md5" 2>/dev/null || true
        BACKUP_COUNT=$(( BACKUP_COUNT + 1 ))
      fi
    fi
  done
  
  cat << INFO_EOF > "$BACKUP_DIR/backup_info.txt"
========================================================
 POX KERNEL MODEM PARTITION BACKUP
========================================================
Device: Redmi Note 8 Pro (begonia)
Date: $(date 2>/dev/null || echo "Unknown")
Partitions Backed Up: $BACKUP_COUNT
Kernel at Backup: $(uname -a 2>/dev/null || echo "Unknown")
========================================================
INFO_EOF

  ui_print "     [+] Backup Complete: $BACKUP_COUNT modem partitions secured!"
else
  ui_print "     [!] Warning: Could not create persistent backup directory on storage."
fi

# ---------------------------------------------------------
# STAGE 3: Flash Calibrated NVRAM & NVDATA Partitions
# ---------------------------------------------------------
ui_print " "
ui_print " [*] [3/5] Flashing calibrated NVRAM & NVDATA partitions..."
NVRAM_DEV=$(find_partition_block "nvram")
NVDATA_DEV=$(find_partition_block "nvdata")

if [ -f "$MODPATH/nvram.img" ]; then
  if [ -n "$NVRAM_DEV" ] && [ -b "$NVRAM_DEV" ]; then
    ui_print "     - Writing NVRAM -> $NVRAM_DEV..."
    dd if="$MODPATH/nvram.img" of="$NVRAM_DEV" bs=1048576 2>/dev/null || cat "$MODPATH/nvram.img" > "$NVRAM_DEV"
    sync
    ui_print "     [+] SUCCESS: NVRAM partition flashed!"
  else
    ui_print "     [-] FAILED: NVRAM block partition not found!"
  fi
  rm -f "$MODPATH/nvram.img"
fi

if [ -f "$MODPATH/nvdata.img" ]; then
  if [ -n "$NVDATA_DEV" ] && [ -b "$NVDATA_DEV" ]; then
    ui_print "     - Writing NVDATA -> $NVDATA_DEV..."
    dd if="$MODPATH/nvdata.img" of="$NVDATA_DEV" bs=1048576 2>/dev/null || cat "$MODPATH/nvdata.img" > "$NVDATA_DEV"
    sync
    ui_print "     [+] SUCCESS: NVDATA partition flashed!"
  else
    ui_print "     [-] FAILED: NVDATA block partition not found!"
  fi
  rm -f "$MODPATH/nvdata.img"
fi

# ---------------------------------------------------------
# STAGE 4: Deploying Pox Kernel Modem Patcher Module
# ---------------------------------------------------------
ui_print " "
ui_print " [*] [4/5] Deploying Pox Kernel Modem Patcher (md_patcher)..."
chmod 755 "$MODPATH/post-fs-data.sh" 2>/dev/null || true
chmod -R 755 "$MODPATH/bin" 2>/dev/null || true
chmod 644 "$MODPATH/module.prop" 2>/dev/null || true
chmod -R 644 "$MODPATH/vendor/lib/modules" 2>/dev/null || true
set_perm_recursive "$MODPATH/bin" 0 0 0755 0755 2>/dev/null || true
ui_print "     [+] Module binaries & kernel modules configured!"

# Legacy mtk_imei compatibility link
if [ -d "/data/adb/modules" ] && [ ! -d "/data/adb/modules/mtk_imei" ]; then
  ln -sf "pox_imei_fixer" "/data/adb/modules/mtk_imei" 2>/dev/null || true
fi

# Clean installer script
rm -f "$MODPATH/customize.sh" 2>/dev/null || true

# ---------------------------------------------------------
# STAGE 5: Installation Summary
# ---------------------------------------------------------
ui_print " "
ui_print " ========================================================"
ui_print "   [SUCCESS] POX MODEM & IMEI RESTORATION COMPLETE!      "
ui_print " ========================================================"
ui_print "   - Backup Location : $BACKUP_DIR"
ui_print "   - NVRAM Flashed   : $([ -n "$NVRAM_DEV" ] && echo "YES" || echo "FAILED")"
ui_print "   - NVDATA Flashed  : $([ -n "$NVDATA_DEV" ] && echo "YES" || echo "FAILED")"
ui_print "   - Pox md_patcher  : ACTIVE (/data/adb/modules/pox_imei_fixer)"
ui_print "   - Runtime Log     : /data/local/tmp/pox_imei_patcher.log"
ui_print " ========================================================"
ui_print "   Please reboot your phone to activate modem patches.  "
ui_print " ========================================================"
ui_print " "
